<?php

namespace Illuminate\Contracts\Database\Events;

interface MigrationEvent
{
    //
}
